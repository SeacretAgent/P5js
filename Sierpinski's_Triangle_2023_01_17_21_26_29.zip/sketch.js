
let x = 50;
let y = 450;
let size = 400;

let r = 0;
let g = 255;
let b = 0;
let alpha = 255;

function setup() 
{
  createCanvas(500, 500, P2D);
  background(0);

  //stroke(0, 255, 0);
  noFill();
  
genSierpinskiTriangle(x, y, size);
}

function draw() 
{
}

function genSierpinskiTriangle(x, y, size)
{
  
  if (size > 3)
    {
      
      stroke(r, g, b, alpha);
      //b++;
      //alpha -= 0.025;
      
      // Outside Triangle
      triangle(x, y, x + size, y, x + size / 2, y - size / 3 * 2.6);
      
      // Top Triangle
      setTimeout(() => genSierpinskiTriangle(x + size / 4, y - size / 2.3, size / 2), 1500);
      
      // Right Triangle
      setTimeout(() => genSierpinskiTriangle(x + size / 2, y, size / 2), 1500);
      
      // Left Triangle
      setTimeout(() => genSierpinskiTriangle(x, y, size / 2), 1500);
    }
}



































