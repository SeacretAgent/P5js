class Boid 
{
  
  constructor()
  {
    this.position = createVector(random(width), random(height));
    this.velocity = createVector();
    this.acceleration = p5.Vector.random2D();
  }
  
  edges() 
  {
    if (this.position.x > width) {
      this.position.x = 0;
    } else if (this.position.x < 0) {
      this.position.x = width;
    }
    if (this.position.y > height) {
      this.position.y = 0;
    } else if (this.position.y < 0) {
      this.position.y = height;
    }
  }
  
  
  update(magnitude)
  {
    //magnitude += 0.75;
    this.acceleration.setMag(magnitude);
    this.position.add(this.velocity);
    this.velocity.add(this.acceleration);
  }
  
  show()
  {
    var randomColor;
    randomColor = color(random(255), random(255), random(255));
    strokeWeight(1);
    stroke(0, 255, 255);
    point(this.position.x, this.position.y);
  }
}