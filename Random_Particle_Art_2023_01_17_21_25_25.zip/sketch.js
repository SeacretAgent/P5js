/*---------------------------------------*/
/* THANK YOU TO CODING TRAIN ON YOUTUBE! */
/*                                       */
/*          Random Particle Art          */
/*           By:  SeacretAgent           */
/*---------------------------------------*/


const flock = [];
let fr = 60;

function setup() {
  createCanvas(800, 800);
  frameRate(fr);
  
  for (let i = 0; i < 1000; i++)
    {
      flock.push(new Boid());
    }

}

function draw() {
  background(0);
  
  let magnitude = 1;
  for (let boid of flock)
    {
      boid.edges();
      boid.update(magnitude);
      boid.show(); 
    }
}